import torch
import torch.nn as nn
from torchvision.utils import save_image

# مدل مولد با استفاده از CNN و ConvTranspose2d
class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()
        self.init_size = 128 // 4  # همانند اندازه تصویری که در آموزش استفاده کردید
        self.l1 = nn.Sequential(nn.Linear(100, 128 * self.init_size ** 2))
        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(128),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(128, 128, 3, stride=1, padding=1),
            nn.BatchNorm2d(128, 0.8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(128, 64, 3, stride=1, padding=1),
            nn.BatchNorm2d(64, 0.8),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 3, 3, stride=1, padding=1),
            nn.Tanh()
        )

    def forward(self, x):
        out = self.l1(x)
        out = out.view(out.shape[0], 128, self.init_size, self.init_size)
        img = self.conv_blocks(out)
        return img

# بارگیری مدل مولد ذخیره شده
generator = Generator()
generator.load_state_dict(torch.load('generator.pth', weights_only=True))
generator.eval()

# تولید نویز تصادفی
latent_dim = 100
z = torch.randn(1, latent_dim)

# تولید تصویر با استفاده از مدل مولد
gen_img = generator(z)

# ذخیره تصویر تولید شده
save_image(gen_img.data, 'generated_image.png', normalize=True)

print("Image generated and saved as 'generated_image.png'")
